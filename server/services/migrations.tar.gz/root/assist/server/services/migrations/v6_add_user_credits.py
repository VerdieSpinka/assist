# server/services/migrations/v6_add_user_credits.py

from . import Migration
import sqlite3

class V6AddUserCredits(Migration):
    version = 6
    description = "Add credits and credit reset timestamp to users table"

    def up(self, conn: sqlite3.Connection) -> None:
        cursor = conn.cursor()
        
        # Tambahkan kolom credits dengan nilai default 10
        cursor.execute("""
            ALTER TABLE users ADD COLUMN credits INTEGER NOT NULL DEFAULT 10
        """)
        
        # Tambahkan kolom last_credit_reset dengan nilai default waktu saat ini
        cursor.execute("""
            ALTER TABLE users ADD COLUMN last_credit_reset TEXT DEFAULT (STRFTIME('%Y-%m-%dT%H:%M:%fZ', 'now'))
        """)
        
        # Perbarui semua pengguna yang sudah ada yang mungkin memiliki nilai NULL untuk kolom baru
        cursor.execute("""
            UPDATE users SET credits = 10, last_credit_reset = STRFTIME('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE credits IS NULL
        """)
        
        conn.commit()
        print("Successfully added 'credits' and 'last_credit_reset' columns to 'users' table.")

    def down(self, conn: sqlite3.Connection) -> None:
        # Peringatan: Operasi ini tidak didukung secara native di SQLite
        # Cara yang aman adalah membuat tabel baru, salin data, hapus yang lama, lalu ganti nama.
        # Untuk kesederhanaan, kami hanya akan mencatat bahwa ini tidak didukung.
        print("Dropping columns is not directly supported in all versions of SQLite.")
        print("Manual table recreation would be needed to fully roll back this migration.")
        # Jika Anda perlu implementasi rollback penuh, Anda harus mengikuti proses recreate-table.